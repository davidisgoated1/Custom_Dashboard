const ctx = document.getElementById('myChart').getContext('2d');

const myChart = new Chart(ctx, {
    type: 'line',
    data: {
        labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May'],
        datasets: [{
            label: 'Revenue',
            data: [12, 19, 3, 5, 15],
            backgroundColor: 'rgba(102, 204, 255, 0.2)',
            borderColor: '#66ccff',
            borderWidth: 2,
            tension: 0.4,
            fill: true,
            pointBackgroundColor: '#1c2c4c',
            pointBorderColor: '#66ccff'
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            legend: {
                labels: {
                    color: '#1c2c4c',
                    font: {
                        weight: 'bold'
                    }
                }
            }
        },
        scales: {
            x: {
                ticks: { color: '#1c2c4c' },
                grid: { color: '#e0e7ef' }
            },
            y: {
                ticks: { color: '#1c2c4c' },
                grid: { color: '#e0e7ef' }
            }
        }
    }
});

async function updateChart() {
    try {
        const response = await fetch('/api/stats/');
        const data = await response.json();

        myChart.data.labels = data.labels || ['Jan', 'Feb', 'Mar', 'Apr', 'May'];
        myChart.data.datasets[0].data = data.values || [12, 19, 3, 5, 15];
        myChart.update();
    } catch (error) {
        console.error('Chart update failed:', error);
    }
}

// Initial update + set interval
updateChart();
setInterval(updateChart, 5000); // Refresh every 5 seconds
