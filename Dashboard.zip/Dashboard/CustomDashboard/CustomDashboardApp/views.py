from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.contrib.auth import authenticate, login
from django.contrib.auth.forms import AuthenticationForm, UserCreationForm
from django.http import JsonResponse
from django.contrib.auth.models import User

@login_required
def dashboard_view(request):
    total_payments = 1253.40
    user_count = 87
    return render(request, 'admin/index.html', {
        'total_payments': total_payments,
        'user_count': user_count,
    })

def custom_login(request):
    if request.method == 'POST':
        form = AuthenticationForm(data=request.POST)
        if form.is_valid():
            login(request, form.get_user())
            return redirect('dashboard')
    else:
        form = AuthenticationForm()
    return render(request, 'registration/login.html', {'form': form})

def register_view(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            return redirect('dashboard')
    else:
        form = UserCreationForm()
    return render(request, 'registration/register.html', {'form': form})

def stats_api(request):
    return JsonResponse({
        'labels': ['Jan', 'Feb', 'Mar', 'Apr', 'May'],
        'values': [1200, 1900, 300, 500, 1500]
    })

def users_page(request):
    # Only admin or superusers can access this page
    if not request.user.is_staff:
        return redirect('dashboard')  # Redirect to dashboard if the user is not staff

    users = User.objects.all()  # Get all users
    return render(request, 'users.html', {'users': users})

def reports_page(request):
    # You can add any dynamic data here that you'd want to show in the reports
    data = {
        'total_sales': 15000,
        'new_users': 125,
        'active_users': 88
    }
    return render(request, 'reports.html', {'data': data})

