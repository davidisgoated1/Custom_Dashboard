from django.urls import path
from . import views

urlpatterns = [
    path('', views.dashboard_view, name='dashboard'),
    path('login/', views.custom_login, name='login'),
    path('register/', views.register_view, name='register'),
    path('api/stats/', views.stats_api, name='stats_api'),
    path('users/', views.users_page, name='users'),
    path('reports/', views.reports_page, name='reports'),  # <- Add this line
]
